﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace BestPrice.Data.Migrations
{
    public partial class AddUserBools : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "getNotified",
                table: "AspNetUsers",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "saveSearches",
                table: "AspNetUsers",
                nullable: false,
                defaultValue: false);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "getNotified",
                table: "AspNetUsers");

            migrationBuilder.DropColumn(
                name: "saveSearches",
                table: "AspNetUsers");
        }
    }
}
