﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BestPrice.Models.ManageViewModels
{
    public class HistoryViewModel
    {
    }
}
